/*++

Copyright (c) Microsoft Corporation

Module Name:

    fxtypedefsKm.hpp

Abstract:

    UMDF side defines for common names for the types
    
Author:



Environment:

    User mode only

Revision History:

--*/

#pragma once

typedef FxDevice CfxDevice;
typedef FxDeviceBase CfxDeviceBase;

