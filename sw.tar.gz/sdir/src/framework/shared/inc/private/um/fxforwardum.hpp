/*++

Copyright (c) Microsoft Corporation

Module Name:

    FxForwardUm.hpp

Abstract:

    UMDF forward defines
    
Author:



Environment:

    User mode only

Revision History:

--*/

#pragma once
class FxMessageDispatch;
class AWDFDevice;
class AWDFDeviceInitialize;
class AWdfDeviceInterface;

