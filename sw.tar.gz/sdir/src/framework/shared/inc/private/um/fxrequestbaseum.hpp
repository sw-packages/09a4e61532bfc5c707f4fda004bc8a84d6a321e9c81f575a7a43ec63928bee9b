/*++

  Copyright (c) Microsoft Corporation

  Module Name:

  FxRequestBaseUm.hpp

  Abstract:

  This module implements km specific functions for FxRequestBase.

  Author:



  Environment:

  User mode only

  Revision History:

  --*/

#ifndef _FXREQUESTBASEUM_HPP_
#define _FXREQUESTBASEUM_HPP_

#endif // _FXREQUESTBASEUM_HPP

