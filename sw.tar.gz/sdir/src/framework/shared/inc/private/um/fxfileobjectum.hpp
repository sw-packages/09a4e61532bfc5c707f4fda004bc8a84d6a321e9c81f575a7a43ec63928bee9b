/*++

Copyright (c) Microsoft Corporation

Module Name:

    FxFileObjectUm.hpp

Abstract:

    This module implements a frameworks managed FileObject

Author:



Environment:

    User mode only

Revision History:


--*/

#ifndef _FXFILEOBJECTUM_H_
#define _FXFILEOBJECTUM_H_

#include "FxFileObject.hpp"

#endif // _FXFILEOBJECTUM_H_


