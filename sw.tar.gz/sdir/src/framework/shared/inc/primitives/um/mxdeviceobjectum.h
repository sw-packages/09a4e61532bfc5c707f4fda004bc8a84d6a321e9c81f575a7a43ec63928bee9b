/*++

Copyright (c) Microsoft Corporation

ModuleName:

    MxDeviceObjectUm.h

Abstract:

    User Mode implementation of Device Object defined in MxDeviceObject.h

--*/

#pragma once


#include "MxDeviceObject.h"
