//
//    Copyright (C) Microsoft.  All rights reserved.
//
#include "fxobjectpch.hpp"
#include "FxMin.hpp"

#include "FxUserObject.hpp"
#include "pnppriv.hpp"

#include "FxObjectInfoDataUm.hpp"
